/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo, useCallback } from 'react';
import { 
  Folder, 
  File, 
  ChevronRight, 
  ChevronDown, 
  Binary, 
  Type, 
  Image as ImageIcon, 
  Search, 
  HardDrive, 
  Clock, 
  Info,
  Database,
  Upload
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

// --- Types ---

interface FileNode {
  name: string;
  path: string;
  kind: 'file' | 'directory';
  size: number;
  lastModified: number;
  type: string;
  children?: FileNode[];
  file?: File; // Reference to the actual File object
}

type ViewTab = 'hex' | 'text' | 'image';

// --- Components ---

/**
 * HexViewer: Formats a Uint8Array into a classic Hex/ASCII view.
 */
const HexViewer = ({ data }: { data: Uint8Array | null }) => {
  if (!data) return <div className="p-4 text-gray-500 font-mono italic">No data loaded.</div>;

  const rows = [];
  const bytesPerRow = 16;

  for (let i = 0; i < Math.min(data.length, 1024 * 10); i += bytesPerRow) {
    const chunk = data.slice(i, i + bytesPerRow);
    const hex = Array.from(chunk)
      .map(b => b.toString(16).padStart(2, '0').toUpperCase())
      .join(' ');
    
    const ascii = Array.from(chunk)
      .map(b => (b >= 32 && b <= 126 ? String.fromCharCode(b) : '.'))
      .join('');

    rows.push(
      <div key={i} className="flex font-mono text-xs leading-tight hover:bg-blue-900/20">
        <span className="text-blue-400 w-24 border-r border-gray-700 mr-4 select-none">
          {i.toString(16).padStart(8, '0').toUpperCase()}
        </span>
        <span className="text-gray-300 w-[350px] border-r border-gray-700 mr-4">
          {hex.padEnd(47, ' ')}
        </span>
        <span className="text-green-400">
          {ascii}
        </span>
      </div>
    );
  }

  return (
    <div className="bg-gray-950 p-4 h-full overflow-auto custom-scrollbar">
      {rows}
      {data.length > 1024 * 10 && (
        <div className="text-gray-500 mt-2 italic">... (Truncated for performance)</div>
      )}
    </div>
  );
};

/**
 * FileTreeItem: Recursive component for the left panel.
 */
interface FileTreeItemProps {
  node: FileNode;
  onSelect: (node: FileNode) => void;
  depth?: number;
  selectedPath?: string;
}

const FileTreeItem: React.FC<FileTreeItemProps> = ({ 
  node, 
  onSelect, 
  depth = 0,
  selectedPath 
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const isSelected = selectedPath === node.path;

  const handleClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (node.kind === 'directory') {
      setIsOpen(!isOpen);
    }
    onSelect(node);
  };

  return (
    <div>
      <div 
        onClick={handleClick}
        className={`flex items-center py-1 px-2 cursor-pointer hover:bg-gray-800 transition-colors ${isSelected ? 'bg-blue-900/40 text-blue-200' : 'text-gray-400'}`}
        style={{ paddingLeft: `${depth * 12 + 8}px` }}
      >
        <span className="mr-1">
          {node.kind === 'directory' ? (
            isOpen ? <ChevronDown size={14} /> : <ChevronRight size={14} />
          ) : (
            <div className="w-[14px]" />
          )}
        </span>
        {node.kind === 'directory' ? (
          <Folder size={16} className="mr-2 text-blue-400" />
        ) : (
          <File size={16} className="mr-2 text-gray-500" />
        )}
        <span className="text-sm truncate select-none">{node.name}</span>
      </div>
      {isOpen && node.children && (
        <div>
          {node.children.map((child, idx) => (
            <FileTreeItem 
              key={idx} 
              node={child} 
              onSelect={onSelect} 
              depth={depth + 1}
              selectedPath={selectedPath}
            />
          ))}
        </div>
      )}
    </div>
  );
};

// --- Main App ---

export default function App() {
  const [fileTree, setFileTree] = useState<FileNode | null>(null);
  const [selectedFolder, setSelectedFolder] = useState<FileNode | null>(null);
  const [selectedFile, setSelectedFile] = useState<FileNode | null>(null);
  const [fileContent, setFileContent] = useState<Uint8Array | null>(null);
  const [textContent, setTextContent] = useState<string | null>(null);
  const [imageContent, setImageContent] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<ViewTab>('hex');
  const [isLoading, setIsLoading] = useState(false);

  // Handle folder selection
  const handleFolderSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    setIsLoading(true);
    const root: FileNode = {
      name: 'Root',
      path: 'root',
      kind: 'directory',
      size: 0,
      lastModified: Date.now(),
      type: '',
      children: []
    };

    // Build tree from flat file list
    Array.from(files).forEach((file: any) => {
      const path = file.webkitRelativePath || file.name;
      const parts = path.split('/');
      let current = root;
      
      parts.forEach((part: string, idx: number) => {
        if (idx === parts.length - 1) {
          // It's a file
          current.children?.push({
            name: part,
            path: path,
            kind: 'file',
            size: file.size,
            lastModified: file.lastModified,
            type: file.type,
            file: file as File
          });
        } else {
          // It's a directory
          let dir = current.children?.find(c => c.name === part && c.kind === 'directory');
          if (!dir) {
            dir = {
              name: part,
              path: parts.slice(0, idx + 1).join('/'),
              kind: 'directory',
              size: 0,
              lastModified: Date.now(),
              type: '',
              children: []
            };
            current.children?.push(dir);
          }
          current = dir;
        }
      });
    });

    setFileTree(root);
    setSelectedFolder(root);
    setIsLoading(false);
  };

  // Handle file selection in list
  const handleFileClick = useCallback(async (node: FileNode) => {
    if (node.kind === 'directory') {
      setSelectedFolder(node);
      return;
    }

    setSelectedFile(node);
    if (!node.file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      const result = e.target?.result;
      if (result instanceof ArrayBuffer) {
        const bytes = new Uint8Array(result);
        setFileContent(bytes);
        
        // Try text
        const text = new TextDecoder().decode(bytes.slice(0, 5000));
        setTextContent(text);

        // Try image
        if (node.type.startsWith('image/')) {
          const blob = new Blob([bytes], { type: node.type });
          setImageContent(URL.createObjectURL(blob));
          setActiveTab('image');
        } else {
          setImageContent(null);
          setActiveTab('hex');
        }
      }
    };
    reader.readAsArrayBuffer(node.file);
  }, []);

  const formatSize = (bytes: number) => {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  return (
    <div className="flex flex-col h-screen bg-gray-900 text-gray-100 font-sans select-none">
      {/* Top Bar */}
      <header className="h-12 bg-gray-800 border-b border-gray-700 flex items-center px-4 justify-between shadow-md z-10">
        <div className="flex items-center gap-3">
          <Database className="text-blue-500" size={20} />
          <h1 className="font-bold text-lg tracking-tight">WebFTK <span className="text-gray-500 font-normal text-sm">v1.0.0</span></h1>
        </div>
        
        <div className="flex items-center gap-4">
          <label className="flex items-center gap-2 bg-blue-600 hover:bg-blue-500 px-3 py-1.5 rounded text-sm font-medium cursor-pointer transition-all shadow-lg active:scale-95">
            <Upload size={16} />
            Load Evidence Folder
            <input 
              type="file" 
              webkitdirectory="" 
              directory="" 
              className="hidden" 
              onChange={handleFolderSelect} 
            />
          </label>
          <div className="h-6 w-px bg-gray-700" />
          <div className="flex items-center gap-2 text-gray-400 hover:text-white cursor-pointer">
            <Search size={18} />
          </div>
          <div className="flex items-center gap-2 text-gray-400 hover:text-white cursor-pointer">
            <Info size={18} />
          </div>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 flex overflow-hidden">
        
        {/* Left Panel: Evidence Tree */}
        <aside className="w-72 bg-gray-900 border-r border-gray-800 flex flex-col shadow-2xl">
          <div className="p-3 border-b border-gray-800 bg-gray-800/50 flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-gray-500">
            <HardDrive size={12} />
            Evidence Tree
          </div>
          <div className="flex-1 overflow-auto py-2 custom-scrollbar">
            {fileTree ? (
              <FileTreeItem 
                node={fileTree} 
                onSelect={(node) => {
                  if (node.kind === 'directory') setSelectedFolder(node);
                  else handleFileClick(node);
                }}
                selectedPath={selectedFolder?.path || selectedFile?.path}
              />
            ) : (
              <div className="p-6 text-center text-gray-600 text-sm italic">
                No evidence loaded. Click "Load Evidence Folder" to begin.
              </div>
            )}
          </div>
        </aside>

        {/* Right Section: Split vertically */}
        <section className="flex-1 flex flex-col overflow-hidden">
          
          {/* Top-Right: File List */}
          <div className="h-1/2 border-b border-gray-800 flex flex-col bg-gray-900">
            <div className="p-2 border-b border-gray-800 bg-gray-800/30 flex items-center justify-between text-xs font-bold uppercase tracking-widest text-gray-500">
              <div className="flex items-center gap-2">
                <Folder size={12} />
                File List: {selectedFolder?.name || 'None'}
              </div>
              <div className="text-[10px] text-gray-600">
                {selectedFolder?.children?.length || 0} items
              </div>
            </div>
            <div className="flex-1 overflow-auto custom-scrollbar">
              <table className="w-full text-left text-sm border-collapse">
                <thead className="sticky top-0 bg-gray-800 text-gray-400 z-10">
                  <tr>
                    <th className="p-2 font-medium border-b border-gray-700">Name</th>
                    <th className="p-2 font-medium border-b border-gray-700">Size</th>
                    <th className="p-2 font-medium border-b border-gray-700">Type</th>
                    <th className="p-2 font-medium border-b border-gray-700">Modified</th>
                  </tr>
                </thead>
                <tbody>
                  {selectedFolder?.children?.map((child, idx) => (
                    <tr 
                      key={idx}
                      onClick={() => handleFileClick(child)}
                      className={`cursor-pointer border-b border-gray-800/50 hover:bg-blue-900/10 transition-colors ${selectedFile?.path === child.path ? 'bg-blue-900/30' : ''}`}
                    >
                      <td className="p-2 flex items-center gap-2">
                        {child.kind === 'directory' ? <Folder size={14} className="text-blue-400" /> : <File size={14} className="text-gray-400" />}
                        <span className="truncate max-w-[300px]">{child.name}</span>
                      </td>
                      <td className="p-2 text-gray-500">{child.kind === 'file' ? formatSize(child.size) : '--'}</td>
                      <td className="p-2 text-gray-400 text-xs">{child.type || (child.kind === 'directory' ? 'Folder' : 'Unknown')}</td>
                      <td className="p-2 text-gray-500 text-xs">{new Date(child.lastModified).toLocaleString()}</td>
                    </tr>
                  ))}
                  {(!selectedFolder || !selectedFolder.children?.length) && (
                    <tr>
                      <td colSpan={4} className="p-8 text-center text-gray-600 italic">No items to display.</td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {/* Bottom-Right: Content Viewer */}
          <div className="h-1/2 flex flex-col bg-gray-950">
            <div className="flex bg-gray-900 border-b border-gray-800">
              <button 
                onClick={() => setActiveTab('hex')}
                className={`px-4 py-2 text-xs font-bold uppercase tracking-widest flex items-center gap-2 border-r border-gray-800 transition-all ${activeTab === 'hex' ? 'bg-gray-950 text-blue-400 border-t-2 border-t-blue-500' : 'text-gray-500 hover:text-gray-300'}`}
              >
                <Binary size={14} /> Hex
              </button>
              <button 
                onClick={() => setActiveTab('text')}
                className={`px-4 py-2 text-xs font-bold uppercase tracking-widest flex items-center gap-2 border-r border-gray-800 transition-all ${activeTab === 'text' ? 'bg-gray-950 text-blue-400 border-t-2 border-t-blue-500' : 'text-gray-500 hover:text-gray-300'}`}
              >
                <Type size={14} /> Text
              </button>
              <button 
                onClick={() => setActiveTab('image')}
                className={`px-4 py-2 text-xs font-bold uppercase tracking-widest flex items-center gap-2 border-r border-gray-800 transition-all ${activeTab === 'image' ? 'bg-gray-950 text-blue-400 border-t-2 border-t-blue-500' : 'text-gray-500 hover:text-gray-300'}`}
              >
                <ImageIcon size={14} /> Image
              </button>
              
              <div className="flex-1 flex items-center justify-end px-4 text-[10px] text-gray-600 font-mono">
                {selectedFile ? `${selectedFile.name} (${formatSize(selectedFile.size)})` : 'No file selected'}
              </div>
            </div>

            <div className="flex-1 overflow-hidden relative">
              <AnimatePresence mode="wait">
                {activeTab === 'hex' && (
                  <motion.div 
                    key="hex"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="h-full"
                  >
                    <HexViewer data={fileContent} />
                  </motion.div>
                )}
                {activeTab === 'text' && (
                  <motion.div 
                    key="text"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="h-full p-4 overflow-auto font-mono text-sm text-gray-300 bg-gray-950 custom-scrollbar whitespace-pre-wrap"
                  >
                    {textContent || <span className="text-gray-600 italic">No text content available.</span>}
                  </motion.div>
                )}
                {activeTab === 'image' && (
                  <motion.div 
                    key="image"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="h-full flex items-center justify-center p-4 bg-gray-950"
                  >
                    {imageContent ? (
                      <img 
                        src={imageContent} 
                        alt="Preview" 
                        className="max-w-full max-h-full object-contain shadow-2xl border border-gray-800" 
                        referrerPolicy="no-referrer"
                      />
                    ) : (
                      <span className="text-gray-600 italic">No image content available.</span>
                    )}
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>
        </section>
      </main>

      {/* Status Bar */}
      <footer className="h-6 bg-blue-700 text-white flex items-center px-3 text-[10px] font-medium justify-between">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-1">
            <Clock size={10} />
            System Time: {new Date().toLocaleTimeString()}
          </div>
          <div className="flex items-center gap-1">
            <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
            Live Analysis Active
          </div>
        </div>
        <div className="flex items-center gap-4 uppercase tracking-tighter">
          <span>Encrypted Session</span>
          <span>Buffer: {fileContent ? (fileContent.length / 1024).toFixed(1) : 0} KB</span>
        </div>
      </footer>

      {/* Global CSS for scrollbars */}
      <style dangerouslySetInnerHTML={{ __html: `
        .custom-scrollbar::-webkit-scrollbar {
          width: 8px;
          height: 8px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: #111827;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: #374151;
          border-radius: 4px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
          background: #4b5563;
        }
      `}} />
    </div>
  );
}
